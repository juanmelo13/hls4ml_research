//Numpy array shape [10]
//Min -0.061617359519
//Max 0.062492337078
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[10];
#else
model_default_t b5[10] = {-0.0616173595, -0.0027288815, -0.0048278021, -0.0356524624, 0.0211006459, 0.0624923371, -0.0206758901, 0.0045045419, 0.0094959456, 0.0065500247};
#endif

#endif
